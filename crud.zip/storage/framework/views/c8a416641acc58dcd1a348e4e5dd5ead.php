
  

  
<?php $__env->startSection('contents'); ?>
  <div class="row">
  <marquee><h1>Welcome Back!!! Dear <?php echo e(auth()->user()->name); ?></h1></marquee>
  <img src="https://www.atatus.com/glossary/content/images/2021/07/CRUD.jpeg" height="460px" width="1900px"></img>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\database_project\resources\views/dashboard.blade.php ENDPATH**/ ?>