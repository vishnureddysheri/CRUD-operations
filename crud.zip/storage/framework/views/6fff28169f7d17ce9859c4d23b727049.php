<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span><b>Copyright © Veera Sai Website 2023</b></span>
    </div>
  </div>
</footer><?php /**PATH F:\xampp\htdocs\laravel\database_project\resources\views/layouts/footer.blade.php ENDPATH**/ ?>